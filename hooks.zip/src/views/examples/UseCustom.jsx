import React from 'react'
import PageTitle from '../../components/layout/PageTitle'

const UseRef = (props) => {
    return (
        <div className="UseCustom">
            <PageTitle
                title="Seu Hook"
                subtitle="Vamos aprender como criar o nosso próprio Hook!"
            />
        </div>
    )
}

export default UseRef
